// コトサーチ管理（パソコン版の管理役）2026-11-16
// AI（Claude・Codex）や管理役の画面から「ボタン」として呼ばれる、決まった操作だけを持つ。任意のコマンドは動かさない。
// 置き場：ホームの下の KotoSearch フォルダ（KOTOSEARCH_HOME で変えられる）。鍵は .env に作り、画面・チャットには出さない。
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { execFile, spawn } from "node:child_process";
import { promisify } from "node:util";
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const run = promisify(execFile);
const HERE = path.dirname(fileURLToPath(import.meta.url));
const BUNDLE = path.join(HERE, "..", "bundle");           // compose.yml と supabase/（拡張に同梱）
const HOME = process.env.KOTOSEARCH_HOME || path.join(os.homedir(), "KotoSearch");
const PROJECT = "kotosearch";
const URL = "http://127.0.0.1:8730";
const PUBKEY = process.env.KOTOSEARCH_LICENSE_PUBKEY || "";    // 運営の公開の鍵（拡張の設定に入れておく）
const DEFAULT_IMAGE = process.env.KOTOSEARCH_IMAGE || "ghcr.io/hazime717/kotosearch-local:0.9.1";

// Mac の Claude Desktop から動かすと PATH に Docker が入っていないことがあるので、よくある場所を足す
process.env.PATH = [process.env.PATH, "/usr/local/bin", "/opt/homebrew/bin", "/Applications/Docker.app/Contents/Resources/bin",
  "C:\\Program Files\\Docker\\Docker\\resources\\bin"].filter(Boolean).join(path.delimiter);

const text = (s) => ({ content: [{ type: "text", text: s }] });
// docker compose には、この管理役の環境の値ではなく KotoSearch/.env の値を使わせる（同じ名前があると環境の値が勝つため外す）
function composeEnv() {
  const env = { ...process.env };
  for (const k of Object.keys(env)) if (k.startsWith("KOTOSEARCH_")) delete env[k];
  return env;
}
const dc = (args, opts = {}) => run("docker", ["compose", "-p", PROJECT, ...args], { cwd: HOME, timeout: 15 * 60 * 1000, env: composeEnv(), ...opts });

async function dockerOk() {
  try { const { stdout } = await run("docker", ["info", "--format", "{{.ServerVersion}}"], { timeout: 20000 }); return stdout.trim(); }
  catch { return null; }
}

function b64u(buf) { return Buffer.from(buf).toString("base64url"); }
function jwt(secret, role) {
  const now = Math.floor(Date.now() / 1000);
  const head = b64u(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body = b64u(JSON.stringify({ role, iss: "supabase", iat: now, exp: now + 20 * 365 * 86400 }));
  const sig = crypto.createHmac("sha256", secret).update(`${head}.${body}`).digest();
  return `${head}.${body}.${b64u(sig)}`;
}

function readEnv() {
  const p = path.join(HOME, ".env");
  if (!fs.existsSync(p)) return {};
  return Object.fromEntries(fs.readFileSync(p, "utf8").split(/\r?\n/).filter((l) => l.includes("=")).map((l) => [l.slice(0, l.indexOf("=")), l.slice(l.indexOf("=") + 1)]));
}
function writeEnv(env) {
  fs.writeFileSync(path.join(HOME, ".env"), Object.entries(env).map(([k, v]) => `${k}=${v}`).join("\n") + "\n", { mode: 0o600 });
}

function ensureFiles() {
  fs.mkdirSync(HOME, { recursive: true });
  fs.cpSync(path.join(BUNDLE, "compose.yml"), path.join(HOME, "compose.yml"));
  fs.cpSync(path.join(BUNDLE, "supabase"), path.join(HOME, "supabase"), { recursive: true });
  const env = readEnv();
  if (!env.POSTGRES_PASSWORD) {            // 初回だけ鍵を作る（2 回目以降は作り直さない＝データを守る）
    const jwtSecret = crypto.randomBytes(30).toString("base64url");
    Object.assign(env, {
      POSTGRES_PASSWORD: crypto.randomBytes(24).toString("hex"),
      JWT_SECRET: jwtSecret,
      ANON_KEY: jwt(jwtSecret, "anon"),
      SERVICE_ROLE_KEY: jwt(jwtSecret, "service_role"),
      DASHBOARD_USERNAME: "unused",
      DASHBOARD_PASSWORD: crypto.randomBytes(16).toString("hex"),
      API_KEY_ENCRYPTION_KEY: crypto.randomBytes(32).toString("base64url") + "=",
      RATE_LIMIT_HASH_KEY: crypto.randomBytes(32).toString("hex"),
    });
  }
  if (PUBKEY) env.KOTOSEARCH_LICENSE_PUBKEY = PUBKEY;
  env.KOTOSEARCH_IMAGE = env.KOTOSEARCH_IMAGE || DEFAULT_IMAGE;
  writeEnv(env);
  return env;
}

function openBrowser(url) {
  const cmd = process.platform === "darwin" ? "open" : process.platform === "win32" ? "cmd" : "xdg-open";
  const args = process.platform === "win32" ? ["/c", "start", "", url] : [url];
  try { spawn(cmd, args, { detached: true, stdio: "ignore" }).unref(); } catch { /* 開けなくても住所を返す */ }
}

async function waitReady(seconds = 240) {
  for (let i = 0; i < seconds / 3; i++) {
    try { const r = await fetch(`${URL}/api/local/status`); if (r.ok) return await r.json(); } catch { /* まだ */ }
    await new Promise((r) => setTimeout(r, 3000));
  }
  return null;
}

const server = new McpServer({ name: "kotosearch-manager", version: "0.2.0" });
// 同じ操作を、AI（MCP）からも、コマンド（node server/index.js install など。Codex・画面なしの手順用）からも呼べるようにする
const TOOLS = {};
function tool(name, meta, handler) {
  TOOLS[name] = { meta, handler };
  server.registerTool(name, meta, handler);
}

tool("check_pc", {
  title: "このパソコンで動くか確かめる（買う前の動作チェック）",
  description: "Docker・メモリ・空き容量を確かめ、コトサーチ（パソコン版）が動くかを日本語で返す。何も変更しない。",
  inputSchema: {},
}, async () => {
  const mem = Math.round(os.totalmem() / 1024 ** 3);
  const d = await dockerOk();
  let freeGb = null;
  try { const s = fs.statfsSync(os.homedir()); freeGb = Math.round((s.bavail * s.bsize) / 1024 ** 3); } catch { /* 古い Node */ }
  const lines = [
    `OS：${os.platform()} ${os.release()}（${os.arch()}）`,
    `メモリ：${mem}GB ${mem >= 8 ? "✓" : "✗（8GB 以上が必要）"}`,
    `空き容量：${freeGb === null ? "確かめられませんでした" : `${freeGb}GB ${freeGb >= 15 ? "✓" : "✗（15GB 以上が必要）"}`}`,
    `Docker：${d ? `✓ 動いています（${d}）` : "✗ 動いていません（Docker Desktop を入れて起動してください）"}`,
  ];
  const ok = mem >= 8 && d && (freeGb === null || freeGb >= 15);
  lines.push(ok ? "→ このパソコンで動きます。" : "→ まだ動かせません。✗ の所を直してから、もう一度確かめてください。");
  return text(lines.join("\n"));
});

tool("install", {
  title: "コトサーチを設置する（初回）／設定を直して起動し直す",
  description: "KotoSearch フォルダに一式を置き、鍵を作り（初回だけ）、本体と部品を取ってきて起動し、ブラウザで開く。データは消さない。",
  inputSchema: {},
}, async () => {
  if (!(await dockerOk())) return text("Docker が動いていません。Docker Desktop を起動してから、もう一度「設置して」と言ってください。");
  ensureFiles();
  try { await dc(["pull", "--ignore-pull-failures", "-q"]); } catch { /* 手元にある箱で続ける */ }
  try { await dc(["up", "-d"]); } catch (e) { return text("起動できませんでした：" + String(e.stderr || e.message).slice(-600)); }
  const st = await waitReady();
  if (!st) return text("起動に時間がかかっています。数分おいて「コトサーチの状態を見て」と言ってください。");
  openBrowser(URL);
  return text(`設置できました（版 ${st.version}）。ブラウザで ${URL} を開きました。\n最初の 1 人を登録 → 購入のメールのライセンスを貼り付け、の順に進めてください。\n※ API キーやライセンスは、このチャットには貼らないでください。`);
});

tool("start", { title: "コトサーチを起動する", description: "止めていたコトサーチを起動してブラウザで開く。", inputSchema: {} }, async () => {
  if (!(await dockerOk())) return text("Docker が動いていません。Docker Desktop を起動してください。");
  if (!fs.existsSync(path.join(HOME, "compose.yml"))) return text("まだ設置されていません。「コトサーチを設置して」と言ってください。");
  await dc(["up", "-d"]);
  const st = await waitReady();
  if (st) openBrowser(URL);
  return text(st ? `起動しました（版 ${st.version}）。${URL}` : "起動に時間がかかっています。少しおいて状態を見てください。");
});

tool("stop", { title: "コトサーチを止める", description: "コトサーチを止める（データは消えない）。", inputSchema: {} }, async () => {
  await dc(["stop"]);
  return text("止めました（データはそのままです）。");
});

tool("status", { title: "コトサーチの状態を見る", description: "動いているか・版・ライセンスの状態を返す。何も変更しない。", inputSchema: {} }, async () => {
  if (!(await dockerOk())) return text("Docker に届きません。Docker Desktop を起動してください。");
  let rows = "";
  try { rows = (await dc(["ps", "--format", "{{.Service}} {{.Status}}"])).stdout.trim(); } catch { /* 未設置 */ }
  if (!rows) return text("コトサーチは動いていません（未設置か、止めています）。");
  let info = "";
  try { const r = await fetch(`${URL}/api/local/status`); if (r.ok) { const s = await r.json(); info = `\n版：${s.version}（${s.release_date}）\nライセンス：${s.license.ok ? `OK（${s.license.email}・更新は ${s.license.updates_until} まで）` : s.license.message}`; } } catch { /* 起動中 */ }
  return text(rows + info);
});

// 控え：止めてから、DB・画像の置き場・ライセンスの入れ物をそのまま固めて保存する（止めるのは数十秒）。
// 鍵（.env）も一緒に入れる（保存した API キーは .env の鍵で暗号化されているので、別のパソコンに戻すときに要る）。
const VOLUMES = ["db-data", "db-config", "storage-data", "license"];
const HELPER_IMAGE = "supabase/postgres:17.6.1.136";   // tar が入っていて、すでに手元にある箱

async function tarVolumes(mode, dir) {
  const mounts = VOLUMES.flatMap((v) => ["-v", `${PROJECT}_${v}:/v/${v}`]);
  const cmd = mode === "save"
    ? ["tar", "czf", "/b/volumes.tar.gz", "-C", "/v", "."]
    : ["sh", "-c", `for v in ${VOLUMES.join(" ")}; do find /v/$v -mindepth 1 -delete; done && tar xzf /b/volumes.tar.gz -C /v`];
  await run("docker", ["run", "--rm", "--user", "0", "--entrypoint", cmd[0], ...mounts, "-v", `${dir}:/b`, HELPER_IMAGE, ...cmd.slice(1)],
    { timeout: 20 * 60 * 1000, env: composeEnv() });
}

async function doBackup(folder) {
  const root = folder || path.join(HOME, "backups");
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const dir = path.join(root, `kotosearch-${stamp}`);
  fs.mkdirSync(dir, { recursive: true });
  let version = "";
  try { const r = await fetch(`${URL}/api/local/status`); if (r.ok) version = (await r.json()).version; } catch { /* 止まっている */ }
  await dc(["stop"]);
  try {
    await tarVolumes("save", dir);
  } finally {
    await dc(["up", "-d"]).catch(() => null);
  }
  fs.copyFileSync(path.join(HOME, ".env"), path.join(dir, "env.txt"));
  fs.chmodSync(path.join(dir, "env.txt"), 0o600);
  fs.writeFileSync(path.join(dir, "about.json"), JSON.stringify({ version, image: readEnv().KOTOSEARCH_IMAGE, at: stamp }, null, 2));
  const mb = (fs.statSync(path.join(dir, "volumes.tar.gz")).size / 1024 ** 2).toFixed(1);
  return { file: dir, mb };
}

function listBackups(folder) {
  const root = folder || path.join(HOME, "backups");
  if (!fs.existsSync(root)) return [];
  return fs.readdirSync(root).filter((n) => n.startsWith("kotosearch-") && fs.existsSync(path.join(root, n, "volumes.tar.gz")))
    .sort().reverse().map((n) => path.join(root, n));
}

tool("backup", {
  title: "控えを取る",
  description: "コトサーチを数十秒止めて、DB・画像・ライセンス・鍵をまとめて KotoSearch/backups（または指定のフォルダ）に日付つきで保存し、また起動する。",
  inputSchema: { folder: z.string().max(500).optional().describe("保存先のフォルダ（任意。iCloud・OneDrive の同期フォルダがおすすめ）") },
}, async ({ folder }) => {
  if (!fs.existsSync(path.join(HOME, ".env"))) return text("まだ設置されていません。");
  const { file, mb } = await doBackup(folder);
  await waitReady(120);
  return text(`控えを取りました：${file}（${mb}MB）\n中に鍵（env.txt）も入っています。人に渡さないでください。`);
});

tool("restore", {
  title: "控えから戻す（別のパソコンへの引っ越しにも使う）",
  description: "控えのフォルダから、DB・画像・ライセンス・鍵を戻す。今のデータは置き換わる（戻す前に今の状態の控えを自動で取る）。confirm が true のときだけ動く。",
  inputSchema: {
    backup: z.string().max(500).optional().describe("控えのフォルダ（省くと KotoSearch/backups の一番新しいもの）"),
    confirm: z.boolean().describe("今のデータを控えの内容に置き換えてよいか（利用者に確かめてから true）"),
  },
}, async ({ backup, confirm }) => {
  if (!confirm) return text("戻すと、今のデータは控えの内容に置き換わります。よければ、もう一度「戻してよい」と伝えてください。");
  if (!(await dockerOk())) return text("Docker が動いていません。Docker Desktop を起動してください。");
  const dir = backup || listBackups()[0];
  if (!dir || !fs.existsSync(path.join(dir, "volumes.tar.gz")) || !fs.existsSync(path.join(dir, "env.txt")))
    return text("控えが見つかりません（volumes.tar.gz と env.txt が入ったフォルダを指定してください）。");
  const about = (() => { try { return JSON.parse(fs.readFileSync(path.join(dir, "about.json"), "utf8")); } catch { return {}; } })();
  let safety = null;
  if (fs.existsSync(path.join(HOME, ".env"))) {
    try { safety = (await doBackup()).file; } catch (e) { return text("今の状態の控えを取れなかったので、戻すのをやめました：" + String(e.message).slice(0, 200)); }
  }
  ensureFiles();
  const env = Object.fromEntries(fs.readFileSync(path.join(dir, "env.txt"), "utf8").split(/\r?\n/).filter((l) => l.includes("=")).map((l) => [l.slice(0, l.indexOf("=")), l.slice(l.indexOf("=") + 1)]));
  if (PUBKEY) env.KOTOSEARCH_LICENSE_PUBKEY = PUBKEY;
  const now = readEnv().KOTOSEARCH_IMAGE;           // 箱は今の版のまま（古い控えでも、起動のときに DB の変更が入る）
  if (now) env.KOTOSEARCH_IMAGE = now;
  writeEnv(env);
  await dc(["down"]).catch(() => null);
  await dc(["create"]);                              // 入れ物（volume）が無ければ作る
  try { await tarVolumes("restore", dir); }
  catch (e) { return text("戻せませんでした：" + String(e.stderr || e.message).slice(-300) + (safety ? `\n戻す前の控え：${safety}` : "")); }
  await dc(["up", "-d"]);
  const st = await waitReady();
  return text(st
    ? `控え（${about.at || path.basename(dir)}）から戻しました。版 ${st.version}。${safety ? `\n戻す前の状態の控え：${safety}` : ""}`
    : "戻しましたが、起動に時間がかかっています。少しおいて状態を見てください。");
});

tool("uninstall", {
  title: "コトサーチを外す",
  description: "コトサーチを止めて外す。keep_data が true（ふつう）ならデータは残す。false ならデータも消す（先に控えを自動で取る）。confirm が true のときだけ動く。",
  inputSchema: {
    keep_data: z.boolean().describe("データを残すか（残すと、あとで「設置して」で元に戻る）"),
    confirm: z.boolean().describe("外してよいか（利用者に確かめてから true）"),
  },
}, async ({ keep_data, confirm }) => {
  if (!confirm) return text("外してよければ、もう一度伝えてください（データを残すかどうかも）。");
  if (!keep_data) {
    let saved = null;
    try { saved = (await doBackup()).file; } catch (e) { return text("控えを取れなかったので、外すのをやめました：" + String(e.message).slice(0, 200)); }
    await dc(["down", "-v"]);
    return text(`止めて、データも消しました。念のための控え：${saved}\n（KotoSearch フォルダは残しています。要らなければご自身で消してください）`);
  }
  await dc(["down"]);
  return text("止めて外しました（データは残っています。「コトサーチを設置して」でまた使えます）。");
});

tool("update", {
  title: "コトサーチを最新にする",
  description: "新しい版があるか確かめ、控えを取ってから入れ替えて起動し直す。DB の変更は起動時に自動で入る。だめなら前の版に戻す。",
  inputSchema: { version: z.string().max(40).optional().describe("入れる版（任意。省くと最新）") },
}, async ({ version }) => {
  const env = readEnv();
  if (!env.KOTOSEARCH_IMAGE) return text("まだ設置されていません。");
  let target = null;
  if (version) target = { version, image: env.KOTOSEARCH_IMAGE.replace(/:[^:]+$/, `:${version}`) };
  else {
    // 新しい版は、コトサーチ本体が運営の署名を確かめたお知らせから知る（管理役は署名の無い情報を使わない）
    try {
      const u = await (await fetch(`${URL}/api/local/update`)).json();
      if (u.latest_version && !u.available) return text(`もう最新です（${u.current_version}）。`);
      if (u.available && u.eligible === false) return text(`新しい版 ${u.latest_version} は、更新の期間（${u.updates_until} まで）の後に出た版のため入れられません。今の版はそのまま使えます。`);
      if (u.available) target = { version: u.latest_version, image: env.KOTOSEARCH_IMAGE.replace(/:[^:]+$/, `:${u.latest_version}`), notes: (u.notes || []).join(" / ") };
    } catch { /* 起動していない・届かない */ }
  }
  if (!target) return text("新しい版の情報を取れませんでした。コトサーチを起動してから、もう一度お試しください。");
  if (target.image === env.KOTOSEARCH_IMAGE) return text(`もう最新です（${target.version}）。`);
  const prev = env.KOTOSEARCH_IMAGE;
  try { await doBackup(); } catch (e) { return text("更新の前の控えを取れなかったので、更新をやめました：" + String(e.message).slice(0, 200)); }
  env.KOTOSEARCH_IMAGE = target.image;
  writeEnv(env);
  try {
    try { await dc(["pull", "-q", "app"]); }
    catch (pullErr) {
      // 置き場から取れなくても、手元に同じ箱があれば続ける（試し・取り直しのとき）
      try { await run("docker", ["image", "inspect", target.image], { timeout: 20000 }); } catch { throw pullErr; }
    }
    await dc(["up", "-d"]);
    let st = null;
    for (let i = 0; i < 40 && !(st && st.version === target.version); i++) { st = await waitReady(30); }
    if (!st || st.version !== target.version) throw new Error("新しい版の起動を確かめられませんでした");
    return text(`${target.version} になりました。${target.notes ? "\n変わったこと：" + target.notes : ""}`);
  } catch (e) {
    env.KOTOSEARCH_IMAGE = prev;
    writeEnv(env);
    await dc(["up", "-d"]).catch(() => null);
    const why = /pull access denied|not found|manifest unknown/i.test(String(e.message)) ? "新しい版の箱を取れませんでした" : String(e.message).slice(0, 200);
    return text(`更新できなかったので、前の版に戻しました（データはそのままです）。理由：${why}`);
  }
});

tool("open", { title: "コトサーチを開く", description: "ブラウザでコトサーチを開く。", inputSchema: {} }, async () => {
  openBrowser(URL);
  return text(`ブラウザで ${URL} を開きました。`);
});

const [, , cmd, ...rest] = process.argv;
if (cmd) {
  // 例：node server/index.js restore --backup /path --confirm true
  const t = TOOLS[cmd];
  if (!t) {
    console.log("使えるもの：" + Object.keys(TOOLS).join(" / "));
    process.exit(2);
  }
  const args = {};
  for (let i = 0; i < rest.length; i += 2) {
    const k = rest[i].replace(/^--/, "").replace(/-/g, "_");
    const v = rest[i + 1];
    args[k] = v === "true" ? true : v === "false" ? false : v;
  }
  try {
    const out = await t.handler(args);
    console.log(out.content.map((c) => c.text).join("\n"));
    process.exit(0);
  } catch (e) {
    console.log("うまくいきませんでした：" + String(e.message || e).slice(0, 400));
    process.exit(1);
  }
} else {
  await server.connect(new StdioServerTransport());
}
