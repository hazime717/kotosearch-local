# コトサーチ管理（パソコン版）— AI への案内

このフォルダは、コトサーチ（パソコン版）の管理役です。利用者に「設置して」「更新して」などと言われたら、
`skills/kotosearch/SKILL.md` の表のとおり、`node server/index.js <操作>` を実行して、返ってきた日本語をそのまま伝えてください。
Node.js が無いときは、利用者の了解を得てから入れてください（Mac：`brew install node`、Windows：`winget install OpenJS.NodeJS.LTS`）。
初めて使うときは、このフォルダで `npm install --omit=dev` を 1 回実行します（同梱済みなら不要）。
API キー・ライセンスはチャットに貼ってもらわず、ブラウザの画面に利用者が自分で入れます。
