---
name: kotosearch
description: コトサーチ（パソコン版）の動作チェック・設置・起動・停止・控え・戻す・更新・外すを行う。「コトサーチを設置して」「更新して」「控えを取って」「動くか確かめて」などと言われたときに使う。
---

# コトサーチ（パソコン版）の管理

利用者のパソコンで動くコトサーチ（SEO 記事の作成と内部リンク設計のツール）を、決まった操作だけで管理する。
操作は「コトサーチ管理」の道具（MCP の tool）で行う。道具が無い環境では、同じフォルダの `server/index.js` をコマンドで呼ぶ
（例：`node server/index.js check_pc`）。任意のコマンドで Docker や中のファイルを直接いじらない。

## 言われたこと → 使う道具

| 利用者の言葉 | 道具 | コマンドで呼ぶとき |
|---|---|---|
| 動くか確かめて／買う前のチェック | check_pc | `node server/index.js check_pc` |
| 設置して／入れて | install | `node server/index.js install` |
| 起動して／開いて | start（動いていれば open） | `node server/index.js start` |
| 止めて | stop | `node server/index.js stop` |
| 状態を見て | status | `node server/index.js status` |
| 控えを取って | backup | `node server/index.js backup` |
| 控えから戻して／引っ越し | restore | `node server/index.js restore --backup <控えのフォルダ> --confirm true` |
| 更新して／最新にして | update | `node server/index.js update` |
| 外して／消して | uninstall | `node server/index.js uninstall --keep-data true --confirm true` |

## 守ること

- **API キー・ライセンス・パスワードをチャットに貼ってもらわない。** それらは、ブラウザで開いたコトサーチの画面に、利用者が自分で入れる。貼られてしまったら、すぐに「キーを作り直してください」と伝える。
- restore（戻す）と uninstall（外す）は、今のデータに関わる。**実行の前に、何が起きるかを一言で伝えて、利用者の「はい」を待ってから** `confirm: true` で呼ぶ。uninstall はふつう `keep_data: true`。
- 更新・戻す・外す（データを消すとき）の前には、道具が自分で控えを取る。控えの場所を利用者に伝える。
- Docker Desktop が動いていないと言われたら、「Docker Desktop を起動してから、もう一度お試しください」と伝える（入れ方は購入のメールの手順）。
- 道具の返事は日本語の短い文。そのまま利用者に伝えてよい。うまくいかないときは、返事の「理由」をそのまま伝え、同じ操作を何度も繰り返さない。
- コトサーチの使い方（記事の作り方など）は、画面の「使い方ガイド」を案内する。
